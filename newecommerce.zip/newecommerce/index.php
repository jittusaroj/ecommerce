<?php include ('includes/header.php')?>
<section style="padding:0px;    margin-top: -30px;">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="assets/banner/b1.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/banner/b1.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/banner/b1.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<style type="text/css">
   .title{
      color:rgba(0,0,0,.87);
      font-weight:500; 
   }
   section{
      padding: 0px 0px;
   }
</style>
</section>
<section>
   <div class="container">
      <div class="row">

<div class="col-md-4 margin-top">  
   <article class="card box">
         <figure class="itemside">
            <div class="aside align-self-center">
               <span class="icon-wrap icon-md round bg-warning">
                  <i class="fa fa heart"></i>
               </span>
            </div>
            <figcaption class="text-wrap">
               <h4 class="title">Sync across all devices</h4>
               <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt ut labor </p>
            </figcaption>
         </figure> <!-- iconbox // -->
      </article> <!-- panel-lg.// -->
   </div><!-- col // -->
   <div class="col-md-4 margin-top">
      <article class="card box">
         <figure class="itemside">
            <div class="aside align-self-center">
               <span class="icon-wrap icon-md round bg-danger">
                  <i class="fa fa-lock white"></i>
               </span>
            </div>
            <figcaption class="text-wrap">
            <h4 class="title">Secured protocol</h4>
            <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt dolor laburab </p>
            </figcaption>
         </figure> <!-- iconbox // -->
      </article> <!-- panel-lg.// -->
   </div>
   <div class="col-md-4 margin-top">
      <article class="card box">
         <figure class="itemside">
            <div class="aside align-self-center">
               <span class="icon-wrap icon-md round bg-danger">
                  <i class="fa fa-lock white"></i>
               </span>
            </div>
            <figcaption class="text-wrap">
            <h4 class="title">Secured protocol</h4>
            <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
               tempor incididunt dolor laburab </p>
            </figcaption>
         </figure> <!-- iconbox // -->
      </article> <!-- panel-lg.// -->
   </div><!-- col // -->
</div> <!-- row.// -->

      
   </div>
</section>
<style type="text/css">
   .title{
      font-weight: 600!important;
   }
   .card-banner{
   height:200px;
}
.crousel-product {
   height:230px;
}
.card-body,.card-footer{
   text-align: center;
}
.ratinglist{
   list-style-type: none;

}
.ratinglist li{
  display: inline;
  margin:0px;
   
}
.fa-star,.fa-star-half-o{
   color: #F1C40F;
}
</style>
<section>
   <div class="container">
      <div class="row">
         <div class="col-md-8 margin-top">
            <div class="row">
         <div class="col-md-6 margin-top">  
<div class="card-banner" style="background-image: url('assets/img/2.jpg');">
  <article class="overlay overlay-cover justify-content-center" style="    background-color: rgba(0, 0, 0, 0.4);">
      <h4 style="font-weight: 600!important;">Men Watch Collection</h4>
      <h5 class="card-title">Save upto 40% OFF</h5>
      <a href="#" class="btn btn-default"> View more </a>
    
  </article>
</div> <!-- card.// -->
  </div>
  <div class="col-md-6 margin-top">
           
<div class="card-banner" style=" background-image: url('assets/img/2.jpg');">
  <article class="overlay overlay-cover justify-content-center" style="    background-color: rgba(0, 0, 0, 0.4);">
      <h4 style="font-weight: 600!important;">Men Watch Collection</h4>
      <h5 class="card-title">Save upto 40% OFF</h5>
      <a href="#" class="btn btn-default"> View more </a>
    
  </article>
</div> <!-- card.// -->
  </div>
  <div class="col-md-6 margin-top">
           
<div class="card-banner" style=" background-image: url('assets/img/2.jpg');">
  <article class="overlay overlay-cover justify-content-center" style="    background-color: rgba(0, 0, 0, 0.4);">
      <h4 style="font-weight: 600!important;">Men Watch Collection</h4>
      <h5 class="card-title">Save upto 40% OFF</h5>
      <a href="#" class="btn btn-default"> View more </a>
    
  </article>
</div> <!-- card.// -->
  </div><div class="col-md-6 margin-top">
           
<div class="card-banner" style=" background-image: url('assets/img/2.jpg');">
  <article class="overlay overlay-cover justify-content-center" style="    background-color: rgba(0, 0, 0, 0.4);">
      <h4 style="font-weight: 600!important;">Men Watch Collection</h4>
      <h5 class="card-title">Save upto 40% OFF</h5>
      <a href="#" class="btn btn-default"> View more </a>
    
  </article>
</div> <!-- card.// -->
  </div>
</div>

</div><br>
<div class="col-md-4" style="    margin-top: 29px;">
   <div class="card-banner" style="height: 415px; background-image: url('assets/img/2.jpg');">
  <article class="overlay overlay-cover justify-content-center" style="    background-color: rgba(0, 0, 0, 0.4);">
      <h4 style="font-weight: 600!important;">Men Watch Collection</h4>
      <h5 class="card-title">Save upto 40% OFF</h5>
      <a href="#" class="btn btn-default"> View more </a>
    
  </article>
</div>
</div>

<!-- card.// -->

      </div>
   </div>
</section>

<section>
   <div class="container">
      <div class="row">
         <div class="col-md-4 margin-top">
            <div class="card">
               <img  src="assets/img/sports.jpg" class="products img-fluid">
            </div>
         </div>
         <div class="col-md-4 margin-top">
            <div class="card">
               <img  src="assets/img/mobile.jpg" class="products img-fluid">
            </div>
         </div>
         <div class="col-md-4 margin-top">
            <div class="card">
               <img  src="assets/img/shoes.jpg" class="products img-fluid">
            </div>
         </div>
         <div class="col-md-4 margin-top">
            <div class="card">
               <img  src="assets/img/headphone.jpg" class="products img-fluid">
            </div>
         </div>
         
         <div class="col-md-4 margin-top">
            <div class="card">
               <img  src="assets/img/watch.jpg" class="products img-fluid">
            </div>
         </div>
         <div class="col-md-4 margin-top">
            <div class="card">
               <img  src="assets/img/t-shirts.jpg" class="products img-fluid">
            </div>
         </div>
      </div>
   </div>
</section>
<br><br>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<section></section>
<div class="container-fluid">

	<div class="row">
		<div class="col-xs-11 col-md-10 col-centered">
         <h4 class="title">Latest Products</h4>
			<div id="carousel" class="carousel slide" data-ride="carousel" data-type="multi" data-interval="2500">
				<div class="carousel-inner">
					<div class="item active">
						<div class="carousel-col">
							<div class="card">
                        <img src="assets/img/1.jpg" class="crousel-product img-fluid">
                        <div class="card-body">
                           <h4 class="title">Sun Glasses</h4>
                           <p>Save 40% off</p>
                           <span style="float: left;"><del>Rs. 500/-</del></span>
                           <span style="float: right;">
                           <ul class="ratinglist">
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
                              </ul>  
                                 <span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
                           </span>
                           <br>
                           <span style="float: left; color: red">Rs. 450/-</span>
                        </div>
                        <div class="card-footer"><ul class="ratinglist">
                                 <li class="list-inline-item">
                                    <button class="btn btn-default"><i class="fa fa-heart"></i></button>
                                 </li>
                                 <li class="list-inline-item">
                                       <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
                                 </li>
                                 
                              </ul> </div>
                     </div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-col">
							<div class="card">
                        <img src="assets/img/1.jpg" class="crousel-product img-fluid">
                        <div class="card-body">
                           <h4 class="title">Sun Glasses</h4>
                           <p>Save 40% off</p>
                           <span style="float: left;"><del>Rs. 500/-</del></span>
                           <span style="float: right;">
                           <ul class="ratinglist">
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
                              </ul>  
                                 <span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
                           </span>
                           <br>
                           <span style="float: left; color: red">Rs. 450/-</span>
                        </div>
                        <div class="card-footer"><ul class="ratinglist">
                                 <li class="list-inline-item">
                                    <button class="btn btn-default"><i class="fa fa-heart"></i></button>
                                 </li>
                                 <li class="list-inline-item">
                                       <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
                                 </li>
                                 
                              </ul> </div>
                     </div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-col">
							<div class="card">
                        <img src="assets/img/1.jpg" class="crousel-product img-fluid">
                        <div class="card-body">
                           <h4 class="title">Sun Glasses</h4>
                           <p>Save 40% off</p>
                           <span style="float: left;"><del>Rs. 500/-</del></span>
                           <span style="float: right;">
                           <ul class="ratinglist">
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
                              </ul>  
                                 <span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
                           </span>
                           <br>
                           <span style="float: left; color: red">Rs. 450/-</span>
                        </div>
                        <div class="card-footer"><ul class="ratinglist">
                                 <li class="list-inline-item">
                                    <button class="btn btn-default"><i class="fa fa-heart"></i></button>
                                 </li>
                                 <li class="list-inline-item">
                                       <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
                                 </li>
                                 
                              </ul> </div>
                     </div>
						</div>
					</div>
					<div class="item">
						<div class="carousel-col">
							<div class="card">
                        <img src="assets/img/1.jpg" class="crousel-product img-fluid">
                        <div class="card-body">
                           <h4 class="title">Sun Glasses</h4>
                           <p>Save 40% off</p>
                           <span style="float: left;"><del>Rs. 500/-</del></span>
                           <span style="float: right;">
                           <ul class="ratinglist">
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
                              </ul>  
                                 <span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
                           </span>
                           <br>
                           <span style="float: left; color: red">Rs. 450/-</span>
                        </div>
                        <div class="card-footer"><ul class="ratinglist">
                                 <li class="list-inline-item">
                                    <button class="btn btn-default"><i class="fa fa-heart"></i></button>
                                 </li>
                                 <li class="list-inline-item">
                                       <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
                                 </li>
                                 
                              </ul> </div>
                     </div>
						</div>
					</div>
				</div>

				<!-- Controls -->
				<div class="left carousel-control" style="margin-right: 40px; margin-left: 0px;">
					<a href="#carousel" role="button" data-slide="prev">
						<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
						<span class="sr-only">Previous</span>
					</a>
				</div>
				<div class="right carousel-control" style="margin-right: 0px; margin-left: -5px;">
					<a href="#carousel" role="button" data-slide="next">
						<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
						<span class="sr-only">Next</span>
					</a>
				</div>
			</div>

		</div>
	</div>
</div>
<style>
.col-centered {
    float: none;
    margin: 0 auto;
}

.carousel-control { 
    width: 8%;
    width: 0px;
}
.carousel-control.left,
.carousel-control.right { 
    margin-right: 40px;
    margin-left: 32px; 
    background-image: none;
    opacity: 1;
}
.carousel-control > a > span {
    color: white;
	  font-size: 29px !important;
}

.carousel-col { 
    position: relative; 
    min-height: 1px; 
    padding: 5px; 
    float: left;
 }

 .active > div { display:none; }
 .active > div:first-child { display:block; }

/*xs*/
@media (max-width: 767px) {
  .carousel-inner .active.left { left: -50%; }
  .carousel-inner .active.right { left: 50%; }
	.carousel-inner .next        { left:  50%; }
	.carousel-inner .prev		     { left: -50%; }
  .carousel-col                { width: 50%; }
	.active > div:first-child + div { display:block; }
}

/*sm*/
@media (min-width: 768px) and (max-width: 991px) {
  .carousel-inner .active.left { left: -50%; }
  .carousel-inner .active.right { left: 50%; }
	.carousel-inner .next        { left:  50%; }
	.carousel-inner .prev		     { left: -50%; }
  .carousel-col                { width: 50%; }
	.active > div:first-child + div { display:block; }
}

/*md*/
@media (min-width: 992px) and (max-width: 1199px) {
  .carousel-inner .active.left { left: -33%; }
  .carousel-inner .active.right { left: 33%; }
	.carousel-inner .next        { left:  33%; }
	.carousel-inner .prev		     { left: -33%; }
  .carousel-col                { width: 33%; }
	.active > div:first-child + div { display:block; }
  .active > div:first-child + div + div { display:block; }
}

/*lg*/
@media (min-width: 1200px) {
  .carousel-inner .active.left { left: -25%; }
  .carousel-inner .active.right{ left:  25%; }
	.carousel-inner .next        { left:  25%; }
	.carousel-inner .prev		     { left: -25%; }
  .carousel-col                { width: 25%; }
	.active > div:first-child + div { display:block; }
  .active > div:first-child + div + div { display:block; }
	.active > div:first-child + div + div + div { display:block; }
}

.block {
	width: 306px;
	height: 230px;
}

.red {background: red;}

.blue {background: blue;}

.green {background: green;}

.yellow {background: yellow;}
</style>
<script>
    $('.carousel[data-type="multi"] .item').each(function() {
	var next = $(this).next();
	if (!next.length) {
		next = $(this).siblings(':first');
	}
	next.children(':first-child').clone().appendTo($(this));

	for (var i = 0; i < 2; i++) {
		next = next.next();
		if (!next.length) {
			next = $(this).siblings(':first');
		}

		next.children(':first-child').clone().appendTo($(this));
	}
});
</script>
</section>
</section>

<br><br>
<?php include ('includes/footer.php');?>