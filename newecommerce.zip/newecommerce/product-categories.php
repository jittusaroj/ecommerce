<?php include ('includes/header.php')?>
    <section>
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">

                        </div>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="card">
                        <div class="card-body">

                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
						<div class="col-md-3 margin-top">
                        	<center>
	                            <div class="card">
	                                <img src="assets/img/1.jpg" class="crousel-product img-fluid">
	                                <div class="card-body">
	                                    <h4 class="title">Sun Glasses</h4>
	                                    <p>Save 40% off</p>
	                                    <span style="float: left;"><del>Rs. 500/-</del></span>
	                                    <span style="float: right;">
				                            <ul class="ratinglist">
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star"></i></li>
				                                 <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
				                            </ul>  
	                                 			<span style="float: right; background-color: #0E6655" class="badge badge-success">4.5 Rating</span>
	                                    </span>
	                                            <br>
	                                    <span style="float: left; color: red">Rs. 450/-</span>
	                                </div>
	                                <div class="card-footer">
	                                    <ul class="ratinglist">
	                                        <li class="list-inline-item"><button class="btn btn-default">
	                                         	<i class="fa fa-heart"></i></button>
	                                        </li>
	                                        <li class="list-inline-item">
	                                            <button class="btn btn-default"><i class="fa fa-shopping-cart"></i></button>
	                                        </li>
										</ul>
	                                </div>
	                            </div>
                            </center>
						</div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <?php include ('includes/footer.php')?>