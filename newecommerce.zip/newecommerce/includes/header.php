<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script type="text/javascript" async="" src="./assets/analytics.js.download"></script><script async="" src="./assets/js"></script>
<script>
 
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("sticky");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>

      
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Osahan Fashion - Bootstrap 4 E-Commerce Theme">
      <meta name="keywords" content="Osahan, fashion, Bootstrap4, shop, e-commerce, modern, flat style, responsive, online store, business, mobile, blog, bootstrap 4, html5, css3, jquery, js, gallery, slider, touch, creative, clean">
      <meta name="author" content="Askbootstrap">
      <title>Osahan Fashion - Bootstrap 4 E-Commerce Theme</title>
      <!-- Favicon Icon -->
      <link rel="apple-touch-icon" sizes="76x76" href="https://askbootstrap.com/preview/osahan-fashion/images/apple-icon.png">
      <link rel="icon" type="image/png" href="https://askbootstrap.com/preview/osahan-fashion/images/favicon.png">
      <!-- Bootstrap core CSS -->
      <link href="./assets/css/bootstrap.min.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="./assets/css/style.css" rel="stylesheet">
      <link href="./assets/css/animate.css" rel="stylesheet">
      <link href="./assets/css/mobile.css" rel="stylesheet">
      <!-- Font Icons -->
      <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="./assets/css/icofont.css" rel="stylesheet" type="text/css">
      <!-- Owl Carousel -->
      <link rel="stylesheet" href="/assets/css/owl.carousel.css">
      <link rel="stylesheet" href="assets/css/owl.theme.css">
      <link rel="stylesheet" href="assets/css/ui.css">
      <link rel="stylesheet" href="assets/css/font.css">

      <style>
         .card{
            box-shadow: 0 2px 1px -1px rgba(0,0,0,.2), 0 1px 1px 0 rgba(0,0,0,.14), 0 1px 3px 0 rgba(0,0,0,.12);
            transition:.6s ease;
         }
         
         .margin-top{
            margin-top:15px;
         }

.card-banner{
   height:200px;
}
.products{
    transition-duration:.6s;
    margin: 0 auto;
    
}
.products:hover {
    transform: scale(1.1);
    
    z-index: 0;
    overflow: hidden;
}

         
  </style>
      
   <script src="./assets/js"></script></head>
   <body>
      <div class="modal fade login-modal-main" id="bd-example-modal">
         <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
               <div class="modal-body">
                  <div class="login-modal">
                     <div class="row">
                        <div class="col-lg-6 pad-right-0">
                           <div class="login-modal-left">
                           </div>
                        </div>
                        <div class="col-lg-6 pad-left-0">
                           <button type="button" class="close close-top-right" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">×</span>
                           <span class="sr-only">Close</span>
                           </button>
                           <form>
                              <div class="login-modal-right">
                                 <!-- Tab panes -->
                                 <div class="tab-content">
                                    <div class="tab-pane active" id="login" role="tabpanel">
                                       <h5 class="heading-design-h5">Login to your account</h5>
                                       <fieldset class="form-group">
                                          <label for="formGroupExampleInput">Enter Email/Mobile number</label>
                                          <input type="text" class="form-control" id="formGroupExampleInput" placeholder="+91 123 456 7890">
                                       </fieldset>
                                       <fieldset class="form-group">
                                          <label for="formGroupExampleInput2">Enter Password</label>
                                          <input type="password" class="form-control" id="formGroupExampleInput2" placeholder="********">
                                       </fieldset>
                                       <fieldset class="form-group">
                                          <button type="submit" class="btn btn-lg btn-theme-round btn-block">Enter to your account</button>
                                       </fieldset>
                                       <div class="login-with-sites text-center">
                                          <p>or Login with your social profile:</p>
                                          <button class="btn-facebook login-icons btn-lg"><i class="fa fa-facebook"></i> Facebook</button>
                                          <button class="btn-google login-icons btn-lg"><i class="fa fa-google"></i> Google</button>
                                          <button class="btn-twitter login-icons btn-lg"><i class="fa fa-twitter"></i> Twitter</button>
                                       </div>
                                       <label class="custom-control custom-checkbox mb-2 mr-sm-2 mb-sm-0">
                                       <input type="checkbox" class="custom-control-input">
                                       <span class="custom-control-indicator"></span>
                                       <span class="custom-control-description">Remember me </span>
                                       </label>
                                       <p class="pull-right"> <a data-toggle="tab" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#forgot" role="tab">
                                          Forgot password
                                          ?</a>
                                       </p>
                                    </div>
                                    <div class="tab-pane" id="register" role="tabpanel">
                                       <h5 class="heading-design-h5">Register Now!</h5>
                                       <fieldset class="form-group">
                                          <label for="formGroupExampleInput">Enter Email/Mobile number</label>
                                          <input type="text" class="form-control" id="formGroupExampleInput" placeholder="+91 123 456 7890">
                                       </fieldset>
                                       <fieldset class="form-group">
                                          <label for="formGroupExampleInput2">Enter Password</label>
                                          <input type="password" class="form-control" id="formGroupExampleInput2" placeholder="********">
                                       </fieldset>
                                       <fieldset class="form-group">
                                          <label for="formGroupExampleInput3">Enter Confirm Password </label>
                                          <input type="password" class="form-control" id="formGroupExampleInput3" placeholder="********">
                                       </fieldset>
                                       <fieldset class="form-group">
                                          <button type="submit" class="btn btn-lg btn-theme-round btn-block">Create Your Account</button>
                                       </fieldset>
                                       <p>
                                          <label class="custom-control custom-checkbox mb-2 mr-sm-2 mb-sm-0">
                                          <input type="checkbox" class="custom-control-input">
                                          <span class="custom-control-indicator"></span>
                                          <span class="custom-control-description">I Agree with Term and Conditions  </span>
                                          </label>
                                       </p>
                                    </div>
                                    <div class="tab-pane" id="forgot" role="tabpanel">
                                       <h5 class="heading-design-h5">Reset Password!</h5>
                                       <fieldset class="form-group">
                                          <label for="formGroupExampleInput">Enter Email/Mobile number</label>
                                          <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Enter Email/Mobile number">
                                       </fieldset>
                                       <fieldset class="form-group">
                                          <button type="submit" class="btn btn-lg btn-theme-round btn-block">Reset Password</button>
                                       </fieldset>
                                    </div>
                                 </div>
                                 <div class="clearfix"></div>
                                 <div class="text-center login-footer-tab">
                                    <ul class="nav nav-tabs" role="tablist">
                                       <li class="nav-item">
                                          <a class="nav-link active" data-toggle="tab" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#login" role="tab"><i class="icofont icofont-lock"></i> LOGIN</a>
                                       </li>
                                       <li class="nav-item">
                                          <a class="nav-link" data-toggle="tab" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#register" role="tab"><i class="icofont icofont-pencil-alt-5"></i> REGISTER</a>
                                       </li>
                                    </ul>
                                 </div>
                                 <div class="clearfix"></div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="navbar-top navbar-top-3">
         <div class="container">
            <div class="row">
               <div class="col-lg-6 col-sm-6 col-xs-6 col-md-6 text-left">
                  <p>
                     End Of Reason Sale- Get Min <span class="text-warning">40- 80%</span> off! 
                  </p>
               </div>
               <div class="col-lg-6 col-sm-6 col-xs-6 col-md-6 text-right">
                  <ul class="list-inline">
                     <li class="list-inline-item">
                        <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#"><i class="icofont icofont-iphone"></i> +1-123-456-7890</a>
                     </li>
                     <li class="list-inline-item">
                        <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#"><i class="icofont icofont-headphone-alt"></i> Contact Us</a>
                     </li>
                     <li class="list-inline-item">
                        <span>Download App</span> &nbsp;
                        <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#"><i class="icofont icofont-brand-windows"></i></a>
                        <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#"><i class="icofont icofont-brand-apple"></i></a>
                        <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#"><i class="icofont icofont-brand-android-robot"></i></a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <nav class="navbar navbar-light navbar-expand-lg bg-primary bg-faded osahan-menu osahan-menu-top-3" id="sticky" >
         <div class="container">
            <a class="navbar-brand" href="https://askbootstrap.com/preview/osahan-fashion/index.html"> <img src="./assets/logo-white.png" alt="logo"> </a>
            <button class="navbar-toggler navbar-toggler-white" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-collapse" id="navbarNavDropdown">
               <div class="navbar-nav mr-auto mt-2 mt-lg-0 margin-auto top-categories-search-main">
                  <div class="top-categories-search">
                     <div class="input-group">
                        <span class="input-group-btn categories-dropdown">
                           <select class="form-control select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                              <option selected="selected">All Categories</option>
                              <optgroup label="Men&#39;s">
                                 <option value="0">Footwear</option>
                                 <option value="2">Bags &amp; Luggage</option>
                                 <option value="3">Clothing</option>
                                 <option value="4">Watches</option>
                              </optgroup>
                              <optgroup label="Women&#39;s">
                                 <option value="5">Fashion Jewellery </option>
                                 <option value="6">Bags &amp; Luggage </option>
                                 <option value="4">Watches</option>
                              </optgroup>
                           </select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 24px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-9hpk-container"><span class="select2-selection__rendered" id="select2-9hpk-container" title="All Categories">All Categories</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                        </span>
                        <input class="form-control" placeholder="Search products &amp; brands" aria-label="Search products &amp; brands" type="text">
                        <span class="input-group-btn">
                        <button class="btn btn-dark" type="button"><i class="icofont icofont-search-alt-2"></i> Search</button>
                        </span>
                     </div>
                  </div>
               </div>
               <div class="my-2 my-lg-0">
                  <ul class="list-inline main-nav-right">
                     <li class="list-inline-item dropdown osahan-top-dropdown">
                        <a class="btn btn-danger dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icofont icofont-shopping-cart"></i> Cart <small class="cart-value">02</small>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right cart-dropdown">
                           <div class="dropdown-item">						
                              <a class="pull-right" data-toggle="tooltip" data-placement="top" title="" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-original-title="Remove">
                              <i class="fa fa-trash-o"></i>
                              </a>
                              <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">
                              <img class="img-fluid" src="./assets/1.jpg" alt="Product">
                              <strong>Ipsums Dolors Untra </strong>
                              <small>Color : Red | Size : M</small>
                              <span class="product-desc-price">$529.99</span>
                              <span class="product-price text-danger">$329.99</span>
                              </a>
                           </div>
                           <div class="dropdown-item">						
                              <a class="pull-right" data-toggle="tooltip" data-placement="top" title="" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-original-title="Remove">
                              <i class="fa fa-trash-o"></i>
                              </a>
                              <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">
                              <img class="img-fluid" src="./assets/3.jpg" alt="Product">
                              <strong>Ipsums Dolors Untra </strong>
                              <small>Color : Black | Size : XL</small>
                              <span class="product-desc-price">$82.99</span>
                              <span class="product-price text-danger">$36.99</span>
                              </a>
                           </div>
                           <div class="dropdown-item">						
                              <a class="pull-right" data-toggle="tooltip" data-placement="top" title="" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-original-title="Remove">
                              <i class="fa fa-trash-o"></i>
                              </a>
                              <a href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">
                              <img class="img-fluid" src="./assets/2.jpg" alt="Product">
                              <strong>Ipsums Dolors Untra </strong>
                              <small>Color : white | Size : L</small>
                              <span class="product-desc-price">$29.99</span>
                              <span class="product-price text-danger">$20.99</span>
                              </a>
                           </div>
                           <div class="dropdown-divider"></div>
                           <div class="dropdown-cart-footer text-center">
                              <h4> <strong>Subtotal</strong>: $210 </h4>
                              <a class="btn btn-sm btn-danger" href="https://askbootstrap.com/preview/osahan-fashion/view-cart.html"> <i class="icofont icofont-shopping-cart"></i> VIEW
                              CART </a> <a href="https://askbootstrap.com/preview/osahan-fashion/cart_checkout.html" class="btn btn-sm btn-primary"> CHECKOUT </a>
                           </div>
                        </div>
                     </li>
                     <li class="list-inline-item">
                        <a class="btn btn-danger" data-toggle="modal" data-target="#bd-example-modal" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#"><i class="icofont icofont-ui-user"></i> Sign In</a>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </nav>
      <nav class="navbar navbar-expand-lg navbar-light bg-light osahan-menu osahan-menu-3 pad-none-mobile" style="    margin-top: -20px;">
         <div class="container">
            <div class="collapse navbar-collapse" id="navbarText">
               <ul class="navbar-nav mr-auto">
                  <li class="nav-item dropdown active">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     <i class="icofont icofont-ui-home"></i> Home <span class="sr-only">(current)</span>
                     </a>
                     <div class="dropdown-menu">
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/index.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Home Version 1 </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/index2.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Home Version 2 </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/index3.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Home Version 3 </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/index4.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Home Version 4 </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/index5.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Home Version 5 </a>
                     </div>
                  </li>
                  <li class="nav-item dropdown mega-dropdown-main">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Men
                     </a>
                     <div class="dropdown-menu mega-dropdown">
                        <div class="row">
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Clothing <span class="badge badge-danger">HOT</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Casual shirt</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Trousers</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Suits &amp; Blazers <span class="badge badge-warning">20%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sportswear </a>
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Eyewear </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Backpacks</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Ray-Ban <span class="badge badge-info">NEW</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Opium </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Joe Black </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Jewellery <span class="badge badge-secondary">50%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Gold</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Platinum</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Rings </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Neckwear </a>
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Watches <span class="badge badge-primary">25% OFF</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Fastrack </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Timex </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Citizen</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Titan <span class="badge badge-light">60%</span></a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Shoes <span class="badge badge-success">SALE</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sports &amp; Outdoor</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Mocassins</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sneakers </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Formal Shoes </a>
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Accessories </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Handbags <span class="badge badge-dark">NEW</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sunglasses</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Clutches </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Backpacks </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3 mega-dropdown-ads">
                              <span class="mega-menu-img hidden-sm"> <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html"><img src="./assets/men-top.png" alt="Bannar 1"></a> </span>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="sale-nav nav-item dropdown mega-dropdown-main">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Women
                     </a>
                     <div class="dropdown-menu mega-dropdown">
                        <div class="row">
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3 mega-dropdown-ads">
                              <span class="mega-menu-img hidden-sm"> <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html"><img src="./assets/women-top.png" alt="Bannar 1"></a> </span>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Eyewear <span class="badge badge-primary">NEW</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Backpacks</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Ray-Ban</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Opium <span class="badge badge-secondary">20%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Joe Black </a>
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Clothing <span class="badge badge-success">SALE</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Casual shirt</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Trousers</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Suits &amp; Blazers </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sportswear </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Watches <span class="badge badge-default">HOT</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Fastrack </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Timex </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Citizen <span class="badge badge-success">5%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Titan </a>
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Jewellery </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Gold</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Platinum</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Rings </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Neckwear <span class="badge badge-light">25%</span> </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Shoes  <span class="badge badge-danger">60%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sports &amp; Outdoor</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Mocassins</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sneakers <span class="badge badge-dark">10%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Formal Shoes </a>
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Accessories <span class="badge badge-warning">50% OFF</span> </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Handbags</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sunglasses</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Clutches </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Backpacks <span class="badge badge-info">HOT</span></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item dropdown mega-dropdown-main">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Kids
                     </a>
                     <div class="dropdown-menu mega-dropdown">
                        <div class="row">
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Baby clothing <span class="badge badge-info">10% OFF</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Casual shirt</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Trousers</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Suits &amp; Blazers </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sportswear </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Boys <span class="badge badge-danger">HOT</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Clothing</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Shoes</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Watches <span class="badge badge-primary">5% OFF</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sunglasses </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Girls </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Baby Girl <span class="badge badge-dark">10%</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Shoes <span class="badge badge-warning">NEW</span></a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Watches </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Sunglasses </a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3 mega-dropdown-ads">
                              <span class="mega-menu-img hidden-sm"> <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html"><img src="./assets/kids-top.png" alt="Bannar 1"></a> </span>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item dropdown mega-dropdown-main">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Pages
                     </a>
                     <div class="dropdown-menu mega-dropdown" style="display: none;">
                        <div class="row">
                           <div class="col-lg-2 col-sm-2 col-xs-2 col-md-2">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Shop Pages </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-full.html">Shop Grid Full width </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-right-sidebar.html">Shop Grid Right Sidebar</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-grid-left-sidebar.html">Shop Grid Left Sidebar</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-list-full.html">Shop List Full width </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-list-right-sidebar.html">Shop List Right Sidebar</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-list-left-sidebar.html">Shop List Left Sidebar</a>
                              </div>
                           </div>
                           <div class="col-lg-2 col-sm-2 col-xs-2 col-md-2">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Product Pages </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/category.html">Category Page</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shop-detail.html">Shop Detail</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/wishlist.html">Wishlists </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/wishlist-user.html">My Wishlist </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/compare.html">Compare </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/quick_view.html">Quick View </a>
                              </div>
                           </div>
                           <div class="col-lg-2 col-sm-2 col-xs-2 col-md-2">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Cart Pages </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/view-cart.html">Cart </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/cart_order.html">Cart Order</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/cart_checkout.html">Cart Checkout</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/cart_delivery.html">Cart Delivery</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/cart_done.html">Thanks for order</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/shopping_cart.html">Shopping Cart Tabs</a>
                              </div>
                           </div>
                           <div class="col-lg-2 col-sm-2 col-xs-2 col-md-2">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Account Pages </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/my-profile.html">My Profile</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/my-address.html">My Address</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/order-list.html">Order List</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/order-status.html">Order Status</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/invoice.html">Invoice A4</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/about.html">About Us </a>
                              </div>
                           </div>
                           <div class="col-lg-2 col-sm-2 col-xs-2 col-md-2">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Static Pages </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/faq.html">FAQ </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/login.html">Login</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/register.html">Register</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/login.html">Login Modal</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/terms-conditions.html">Terms and Conditions </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/privacy-policy.html">Privacy Policy</a>
                              </div>
                           </div>
                           <div class="col-lg-2 col-sm-2 col-xs-2 col-md-2">
                              <div class="mega-list"><a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">Other Pages </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/blog-right.html">Blog – Right Sidebar </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/blog-left.html">Blog – Left Sidebar </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/blog.html">Blog – Full-Width </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/blog-single.html">Single post </a> 
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/email-template.html">Email Template </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/404.html">Error 404 </a>
                              </div>
                           </div>
                        </div>
                        <div class="row services-block">
                           <div class="col-xl-3 col-lg-6 d-flex">
                              <div class="item d-flex align-items-center">
                                 <div class="icon"><i class="icofont icofont-free-delivery text-primary"></i></div>
                                 <div class="text"><span class="text-uppercase">Free shipping &amp; return</span><small>Free Shipping over $300</small></div>
                              </div>
                           </div>
                           <div class="col-xl-3 col-lg-6 d-flex">
                              <div class="item d-flex align-items-center">
                                 <div class="icon"><i class="icofont icofont-money-bag text-primary"></i></div>
                                 <div class="text"><span class="text-uppercase">Money back guarantee</span><small>30 Days Money Back</small></div>
                              </div>
                           </div>
                           <div class="col-xl-3 col-lg-6 d-flex">
                              <div class="item d-flex align-items-center">
                                 <div class="icon"><i class="icofont icofont-headphone-alt-2 text-primary"></i></div>
                                 <div class="text"><span class="text-uppercase">020-800-456-747</span><small>24/7 Available Support</small></div>
                              </div>
                           </div>
                           <div class="col-xl-3 col-lg-6 d-flex">
                              <div class="item d-flex align-items-center">
                                 <div class="icon"><i class="icofont icofont-shield text-primary"></i></div>
                                 <div class="text"><span class="text-uppercase">Secure Payment</span><small>Secure Payment</small></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item dropdown mega-dropdown-main">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Components
                     </a>
                     <div class="dropdown-menu mega-dropdown mega-list-arrow-none">
                        <div class="row">
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">A - C </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/alerts.html"><i class="icofont icofont-exclamation-tringle"></i> Alerts</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/badge.html"><i class="icofont icofont-file-alt"></i> Badge</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/breadcrumb.html"><i class="icofont icofont-all-caps"></i> Breadcrumb</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/button-group.html"><i class="icofont icofont-ui-social-link"></i> Button Group</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/buttons.html"><i class="icofont icofont-link-alt"></i> Buttons</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/card.html"><i class="icofont icofont-ui-v-card"></i> Card</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/carousel.html"><i class="icofont icofont-image"></i> Carousel</a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">A - I </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/collapse.html"><i class="icofont icofont-listing-box"></i> Collapse</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/dropdowns.html"><i class="icofont icofont-line-block-down"></i> Dropdowns</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/figures.html"><i class="icofont icofont-paper"></i> Figures</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/forms.html"><i class="icofont icofont-ui-edit"></i> Forms</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/grid-system.html"><i class="icofont icofont-calculations"></i> Grid System</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/images.html"><i class="icofont icofont-ui-image"></i> Images</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/input-group.html"><i class="icofont icofont-paperclip"></i> Input Group</a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">J - P </a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/jumbotron.html"><i class="icofont icofont-page"></i> Jumbotron</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/list-group.html"><i class="icofont icofont-list"></i> List Group</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/media-object.html"><i class="icofont icofont-multimedia"></i> Media Object</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/modal.html"><i class="icofont icofont-picture"></i> Modal</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/nav.html"><i class="icofont icofont-square"></i> Nav</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/navbar.html"><i class="icofont icofont-navigation-menu"></i> Navbar</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/pagination.html"><i class="icofont icofont-bubble-right"></i> Pagination</a>
                              </div>
                           </div>
                           <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                              <div class="mega-list">
                                 <a class="mega-title" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#">P - T</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/popovers.html"><i class="icofont icofont-scroll-right"></i> Popovers</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/progress.html"><i class="icofont icofont-circle-ruler"></i> Progress</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/blank-page.html"><i class="icofont icofont-paper"></i> Page Blank</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/scrollspy.html"><i class="icofont icofont-hand-drag1"></i> Scrollspy</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/tables.html"><i class="icofont icofont-table"></i> Tables</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/tooltips.html"><i class="icofont icofont-cursor-drag"></i> Tooltips</a>
                                 <a href="https://askbootstrap.com/preview/osahan-fashion/typography.html"><i class="icofont icofont-line-height"></i> Typography</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item dropdown">
                     <a class="nav-link dropdown-toggle" href="https://askbootstrap.com/preview/osahan-fashion/index3.html#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                     Blog
                     </a>
                     <div class="dropdown-menu">
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/blog-right.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Blog – Right Sidebar </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/blog-left.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Blog – Left Sidebar </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/blog.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Blog – Full-Width </a>
                        <a class="dropdown-item" href="https://askbootstrap.com/preview/osahan-fashion/blog-single.html"><i class="fa fa-angle-right" aria-hidden="true"></i> Single post </a> 
                     </div>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="https://askbootstrap.com/preview/osahan-fashion/contact.html">Contact</a>
                  </li>
               </ul>
               <span class="navbar-text">	Worlds's Fastest <b class="text-primary">Online Shopping</b> Destination</span>
            </div>
         </div>
      </nav>